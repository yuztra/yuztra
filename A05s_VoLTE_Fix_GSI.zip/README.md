## Module description
VoLTE fix for GSI

## Reminders


## Features


## Bugs

## Compatibility
*fix only for Q GSI

## Changelog
